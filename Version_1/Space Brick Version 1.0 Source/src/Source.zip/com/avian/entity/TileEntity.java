package com.avian.entity;

import java.awt.image.BufferedImage;

import com.avian.engine.Visuals;
import com.avian.level.GameLevel;

public class TileEntity extends GameEntity 
{
	private BufferedImage texture, overTexture;
	
	public TileEntity(int id, GameLevel level, int xPos, int yPos, int drawX, int drawY, double theta, BufferedImage type)
	{
		super(level, xPos, yPos, drawX, drawY, theta);
		
		texture = type;
		
		createHitboxSystem(id);
	}
	
	public TileEntity(int id, GameLevel level, int xPos, int yPos, int drawX, int drawY, double theta, BufferedImage type, BufferedImage over)
	{
		super(level, xPos, yPos, drawX, drawY, theta);
		
		texture = type;
		overTexture = over;
		
		createHitboxSystem(id);
	}
	
	public void createHitboxSystem(int id)
	{
		if(id < 2)
		{
			return;
		}
		
		if(id == 2 || id == 12 || id == 13)
		{
			addHitboxes(new Hitbox[]{
					new Hitbox(0, -DRAWY / 4, DRAWX, DRAWY * 7 / 8, true)
			});
		}
		
		if(id == 3 || id == 4 || id == 6 || id == 7 || id == 8 || id == 9 || id == 14 || id == 15 || id > 16)
		{
			addHitboxes(new Hitbox[]{
					new Hitbox(0, 0, DRAWX, DRAWY, true)
			});
		}
		
		if(id == 5 || id == 10 || id == 11 || id == 16)
		{
			addHitboxes(new Hitbox[]{
					new Hitbox(0, DRAWY * 3 / 8, DRAWX, DRAWY / 16, true)
			});
		}
	}
	
	public void onActivate() 
	{
		
	}
	
	public void onDeactivate() 
	{
		
	}
	
	public void onRender(Visuals v) 
	{
		LEVEL.renderOnAtPoint(v, texture, XPOS, YPOS, DRAWX, DRAWY + 1);
	}
	
	public void lateRender(Visuals v)
	{
		if(overTexture != null)
		{
			LEVEL.renderOnAtPoint(v, overTexture, XPOS, YPOS, DRAWX, DRAWY + 1);
		}
	}
	
	public void onTick()
	{
		SHOW_HITBOXES = false;
	}
	
	public void onCollide(GameEntity hit)
	{
		
	}
}
