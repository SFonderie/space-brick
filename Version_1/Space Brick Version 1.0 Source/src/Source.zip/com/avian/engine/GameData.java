package com.avian.engine;

public class GameData 
{
	public String CHAR_NAME;
	
	public GameData(String name)
	{
		CHAR_NAME = name;
	}
}
